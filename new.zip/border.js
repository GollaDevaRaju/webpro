$(document).ready(function() {
    // Add 'hovered' class on hover, remove it on mouseout
    $('.menu-item').hover(
        function() {
            // Mouse enters the item: add 'hovered' class
            $(this).addClass('hovered');
        },
        function() {
            // Mouse leaves the item: remove 'hovered' class
            $(this).removeClass('hovered');
        }
    );
});
