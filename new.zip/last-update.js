
/* playmore btn */

$(document).ready(function(){
$("#pbtn").hover(function(){
        $(this).css("background-color","#40a4d6"); 
    },
    function(){
        $(this).css("background-color","#002c73");
    }); 
});

/*knowmore*/
$(document).ready(function(){
    $("#kbtn").hover(function(){
            $(this).css("background-color","#002c73"); 
        },
        function(){
            $(this).css("background-color","#40a4d6");
        }); 
    });


/*list-style*/
$(document).ready(function() {
    // Add 'hovered' class on hover, remove it on mouseout
    $('.menu-item').hover(
        function() {
            // Mouse enters the item: add 'hovered' class
            $(this).addClass('hovered');
        },
        function() {
            // Mouse leaves the item: remove 'hovered' class
            $(this).removeClass('hovered');
        }
    );
});






/*playing-video*/
$(document).ready(function() {
    // Show the custom modal when the button is clicked
    $("#show-video-btn-alert").click(function() {
      $("#video-Modal").fadeIn();
    });

    // Close the modal when the close button is clicked
    $("#closeModal").click(function() {
      $("#video-Modal").fadeOut();
    });
  });
    

/*social media*/
  $(document).ready(function(){
            $("#icon-face").hover(
                function () {
                        $(this).css("fill","#002c73"  );
                   },
                function(){
                     $(this).css("fill","white");
                   }
            );
        });

/*linkdin*/
$(document).ready(function(){
    $("#icon-linkdin").hover(
        function () {
                $(this).css("fill","#002c73"  );
           },
        function(){
             $(this).css("fill","white");
           }
    );
});

/*google icon*/

$(document).ready(function(){
    $("#icon-google").hover(
        function () {
                $(this).css("fill","#002c73");
           },
        function(){
             $(this).css("fill","white");
           }
    );
});

/*twitter*/
$(document).ready(function(){
    $("#icon-twitter").hover(
        function () {
                $(this).css("fill","#002c73");
           },
        function(){
             $(this).css("fill","white");
           }
    );
});
